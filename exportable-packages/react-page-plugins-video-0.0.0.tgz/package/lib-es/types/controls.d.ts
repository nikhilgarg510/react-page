import type { VideoProps } from './component';
import type { VideoApi } from './api';
export declare type VideoControlsProps = VideoProps & VideoApi;
//# sourceMappingURL=controls.d.ts.map