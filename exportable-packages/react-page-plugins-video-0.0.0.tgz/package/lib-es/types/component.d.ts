import type { CellPluginComponentProps } from '@react-page/editor';
import type { VideoState } from './state';
export declare type VideoProps = CellPluginComponentProps<VideoState>;
//# sourceMappingURL=component.d.ts.map