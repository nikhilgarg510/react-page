import type { VideoProps } from './component';
export declare type VideoHtmlRendererProps = VideoProps;
//# sourceMappingURL=renderer.d.ts.map