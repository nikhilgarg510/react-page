export declare type VideoState = {
    src: string;
};
//# sourceMappingURL=state.d.ts.map