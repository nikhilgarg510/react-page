export declare type SpacerState = {
    height: number;
};
//# sourceMappingURL=state.d.ts.map