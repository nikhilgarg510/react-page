# @react-page/plugins-background

A background layout plugin for React Page Editor that allows adding customizable background colors and images to layout cells.

## Installation

```bash
npm install @react-page/plugins-background
```

## Usage

```jsx
import background from '@react-page/plugins-background';
import '@react-page/plugins-background/lib/index.css';

const cellPlugins = [background];

<Editor cellPlugins={cellPlugins} />
```

## Features

- Background color customization
- Background image support
- Image positioning and sizing options
- Gradient backgrounds
- Overlay effects
- Parallax scrolling effects

## License

MIT
