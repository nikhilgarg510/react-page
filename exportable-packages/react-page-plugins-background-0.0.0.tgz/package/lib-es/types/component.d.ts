import type { CellPluginComponentProps } from '@react-page/editor';
import type { BackgroundSettings } from './settings';
import type { BackgroundState } from './state';
export declare type BackgroundProps = CellPluginComponentProps<BackgroundState> & BackgroundSettings;
//# sourceMappingURL=component.d.ts.map