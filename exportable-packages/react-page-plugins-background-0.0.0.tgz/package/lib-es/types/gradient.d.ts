import type { RGBColor } from '@react-page/editor';
export declare type Gradient = {
    opacity: number;
    deg: number;
    colors?: {
        color?: RGBColor;
    }[];
};
//# sourceMappingURL=gradient.d.ts.map