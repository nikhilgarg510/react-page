import type { BackgroundProps } from './component';
import type { BackgroundRendererExtraProps } from './renderer';
export declare type BackgroundControlsProps = BackgroundProps & BackgroundRendererExtraProps;
//# sourceMappingURL=controls.d.ts.map