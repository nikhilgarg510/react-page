import type { DisplayModes } from '../actions/display';
export declare type Display = {
    mode: DisplayModes;
    referenceNodeId?: string;
    zoom: number;
};
//# sourceMappingURL=display.d.ts.map