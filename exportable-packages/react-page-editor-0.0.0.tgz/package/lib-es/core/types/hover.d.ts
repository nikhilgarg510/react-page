import type { InsertOptions } from '../actions/cell';
import type { HoverTarget } from '../service/hover/computeHover';
import type { PartialCell } from './node';
export declare type Room = {
    height: number;
    width: number;
};
export declare type Vector = {
    y: number;
    x: number;
};
export declare type MatrixIndex = {
    row: number;
    cell: number;
};
export declare type HoverInsertActions = {
    dragCell(id: string): void;
    cancelCellDrag(): void;
    clear(): void;
    above(drag: PartialCell, hover: HoverTarget, options?: InsertOptions): void;
    below(drag: PartialCell, hover: HoverTarget, options?: InsertOptions): void;
    leftOf(drag: PartialCell, hover: HoverTarget, options?: InsertOptions): void;
    rightOf(drag: PartialCell, hover: HoverTarget, options?: InsertOptions): void;
    inlineLeft(drag: PartialCell, hover: HoverTarget): void;
    inlineRight(drag: PartialCell, hover: HoverTarget): void;
};
export declare type Matrix = Array<Array<number>>;
//# sourceMappingURL=hover.d.ts.map