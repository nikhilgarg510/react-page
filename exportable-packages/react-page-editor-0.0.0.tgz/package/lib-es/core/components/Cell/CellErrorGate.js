var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import React from 'react';
import ErrorCell from './ErrorCell';
export var CellErrorGate = /** @class */ (function (_super) {
    __extends(class_1, _super);
    function class_1() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.state = {
            error: null,
        };
        return _this;
    }
    class_1.prototype.componentDidCatch = function (error) {
        this.setState({ error: error });
        console.error(error);
    };
    class_1.prototype.reset = function () {
        this.setState({ error: null });
    };
    class_1.prototype.render = function () {
        if (this.state.error && this.props.shouldShowError) {
            return (React.createElement(ErrorCell, { nodeId: this.props.nodeId, error: this.state.error, resetError: this.reset.bind(this) }));
        }
        return this.props.children;
    };
    return class_1;
}(React.Component));
//# sourceMappingURL=CellErrorGate.js.map