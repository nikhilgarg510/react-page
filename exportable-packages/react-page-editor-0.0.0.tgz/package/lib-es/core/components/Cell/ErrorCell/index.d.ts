import React from 'react';
declare const ErrorCell: React.FC<{
    nodeId: string;
    error: Error;
    resetError?: () => void;
}>;
export default ErrorCell;
//# sourceMappingURL=index.d.ts.map