var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
import React from 'react';
import { useDrop } from 'react-dnd';
import { useCellIsAllowedHere, useInsertNew, useIsLayoutMode, useIsPreviewMode, useSetDisplayReferenceNodeId, useSetInsertMode, } from '../hooks';
var InsertNew = function (_a) {
    var parentCellId = _a.parentCellId;
    var setInsertMode = useSetInsertMode();
    var insertNew = useInsertNew(parentCellId);
    var isPreviewMode = useIsPreviewMode();
    var isLayoutMode = useIsLayoutMode();
    var setReferenceNodeId = useSetDisplayReferenceNodeId();
    var checkIfAllowed = useCellIsAllowedHere(parentCellId);
    var _b = __read(useDrop({
        accept: 'cell',
        canDrop: function (item) {
            return checkIfAllowed(item);
        },
        collect: function (monitor) { return ({
            isOver: monitor.isOver(),
            isAllowed: checkIfAllowed(monitor.getItem()),
        }); },
        drop: function (item, monitor) {
            // fallback drop
            if (!monitor.didDrop() && item.cell) {
                insertNew(item.cell);
            }
        },
    }), 2), _c = _b[0], isOver = _c.isOver, isAllowed = _c.isAllowed, dropRef = _b[1];
    if (isPreviewMode)
        return null;
    return (React.createElement("div", { ref: dropRef, className: 'react-page-cell-insert-new' + (isOver && isAllowed ? ' hover' : ''), style: {
            pointerEvents: 'all',
            zIndex: isLayoutMode ? 10 : 1,
            overflow: 'hidden',
            width: '50%',
            minWidth: 120,
            margin: 'auto',
            cursor: isOver && !isAllowed ? 'not-allowed' : 'pointer',
        }, onClick: function (e) {
            e.stopPropagation();
            setReferenceNodeId(parentCellId);
            setInsertMode();
        } },
        React.createElement("div", { className: "react-page-cell-insert-new-icon" },
            React.createElement("svg", { focusable: "false", "aria-hidden": "true", viewBox: "0 0 24 24", "data-testid": "AddIcon" },
                React.createElement("path", { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" })))));
};
export default React.memo(InsertNew);
//# sourceMappingURL=InsertNew.js.map