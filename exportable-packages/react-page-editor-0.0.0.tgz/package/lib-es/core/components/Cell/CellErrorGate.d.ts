import React from 'react';
export declare const CellErrorGate: {
    new (props: {
        children: React.ReactNode;
        nodeId: string;
        shouldShowError?: boolean | undefined;
    } | Readonly<{
        children: React.ReactNode;
        nodeId: string;
        shouldShowError?: boolean | undefined;
    }>): {
        state: {
            error: null;
        };
        componentDidCatch(error: Error): void;
        reset(): void;
        render(): string | number | boolean | JSX.Element | React.ReactFragment | null | undefined;
        context: unknown;
        setState<K extends "error">(state: {
            error: Error | null;
        } | ((prevState: Readonly<{
            error: Error | null;
        }>, props: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>) => {
            error: Error | null;
        } | Pick<{
            error: Error | null;
        }, K> | null) | Pick<{
            error: Error | null;
        }, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, prevState: Readonly<{
            error: Error | null;
        }>): any;
        componentDidUpdate?(prevProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, prevState: Readonly<{
            error: Error | null;
        }>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): void;
    };
    new (props: {
        children: React.ReactNode;
        nodeId: string;
        shouldShowError?: boolean | undefined;
    }, context: any): {
        state: {
            error: null;
        };
        componentDidCatch(error: Error): void;
        reset(): void;
        render(): string | number | boolean | JSX.Element | React.ReactFragment | null | undefined;
        context: unknown;
        setState<K extends "error">(state: {
            error: Error | null;
        } | ((prevState: Readonly<{
            error: Error | null;
        }>, props: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>) => {
            error: Error | null;
        } | Pick<{
            error: Error | null;
        }, K> | null) | Pick<{
            error: Error | null;
        }, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, prevState: Readonly<{
            error: Error | null;
        }>): any;
        componentDidUpdate?(prevProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, prevState: Readonly<{
            error: Error | null;
        }>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<{
            children: React.ReactNode;
            nodeId: string;
            shouldShowError?: boolean | undefined;
        }>, nextState: Readonly<{
            error: Error | null;
        }>, nextContext: any): void;
    };
    contextType?: React.Context<any> | undefined;
};
//# sourceMappingURL=CellErrorGate.d.ts.map