import type { PropsWithChildren } from 'react';
import React from 'react';
declare const _default: React.NamedExoticComponent<PropsWithChildren<{
    nodeId: string;
    hasChildren: boolean;
}>>;
export default _default;
//# sourceMappingURL=index.d.ts.map