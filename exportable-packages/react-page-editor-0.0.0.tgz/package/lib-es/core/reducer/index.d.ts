/// <reference types="redux-undo" />
import type { Value, RootState } from '../types';
declare const reducer: import("redux").Reducer<{
    values: import("redux-undo").StateWithHistory<Value | null>;
    display: import("../types").Display | {
        referenceNodeId: string | null | undefined;
        mode: import("../actions/display").DisplayModes;
        zoom: number;
    };
    focus: import("./focus").Focus;
    settings: {
        lang: unknown;
    };
    hover: import("./hover").Hover;
    __nodeCache: null;
}, import("../actions/display").DisplayAction | import("../actions/cell").CellHoverAction | import("redux").Action<string> | import("../actions/cell").ClearHoverAction | import("../actions/cell").RemoveCellAction | import("../actions/cell").FocusCellAction | import("../actions/cell").BlurCellAction | import("../actions/cell").BlurAllCellsAction | import("redux").AnyAction | {
    [key: string]: unknown;
    type: string;
}, Partial<{
    values: import("redux-undo").StateWithHistory<Value | null> | undefined;
    display: never;
    focus: never;
    settings: {
        lang: null;
    } | undefined;
    hover: never;
    __nodeCache: unknown;
}>>;
export { reducer };
declare const _default: import("redux").Reducer<{
    reactPage: {
        values: import("redux-undo").StateWithHistory<Value | null>;
        display: import("../types").Display | {
            referenceNodeId: string | null | undefined;
            mode: import("../actions/display").DisplayModes;
            zoom: number;
        };
        focus: import("./focus").Focus;
        settings: {
            lang: unknown;
        };
        hover: import("./hover").Hover;
        __nodeCache: null;
    };
}, import("../actions/display").DisplayAction | import("../actions/cell").CellHoverAction | import("redux").Action<string> | import("../actions/cell").ClearHoverAction | import("../actions/cell").RemoveCellAction | import("../actions/cell").FocusCellAction | import("../actions/cell").BlurCellAction | import("../actions/cell").BlurAllCellsAction | import("redux").AnyAction | {
    [key: string]: unknown;
    type: string;
}, Partial<{
    reactPage: {
        values: import("redux-undo").StateWithHistory<Value | null>;
        display: import("../types").Display | {
            referenceNodeId: string | null | undefined;
            mode: import("../actions/display").DisplayModes;
            zoom: number;
        };
        focus: import("./focus").Focus;
        settings: {
            lang: unknown;
        };
        hover: import("./hover").Hover;
        __nodeCache: null;
    } | Partial<{
        values: import("redux-undo").StateWithHistory<Value | null> | undefined;
        display: never;
        focus: never;
        settings: {
            lang: null;
        } | undefined;
        hover: never;
        __nodeCache: unknown;
    }> | undefined;
}>>;
export default _default;
export declare function initialState(value: Value | null, lang: string): RootState;
//# sourceMappingURL=index.d.ts.map