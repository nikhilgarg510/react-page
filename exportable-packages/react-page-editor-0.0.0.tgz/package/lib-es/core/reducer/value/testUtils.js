var _a;
import { applyMiddleware, combineReducers, createStore } from 'redux';
import * as reduxThunkModule from 'redux-thunk';
// Handle both ESM and CommonJS exports of redux-thunk
var thunk = ((_a = reduxThunkModule.default) === null || _a === void 0 ? void 0 : _a.default) ||
    reduxThunkModule.default ||
    reduxThunkModule.thunk ||
    reduxThunkModule;
import { value } from './index';
export var simulateDispatch = function (initialState, action) {
    var reducer = combineReducers({ value: value });
    var store = createStore(reducer, { value: initialState }, applyMiddleware(thunk));
    if (action)
        store.dispatch(action);
    return store.getState().value;
};
//# sourceMappingURL=testUtils.js.map