import { findNodeInState } from './editable';
export var focus = function (state) {
    return state && state.reactPage && state.reactPage.focus;
};
// Memoize allFocusedNodeIds to avoid returning a new array reference on every call
var _prevNodeIds;
var _prevState;
var _prevResult = [];
var shallowArrayEqual = function (a, b) {
    if (a.length !== b.length)
        return false;
    for (var i = 0; i < a.length; i++) {
        if (a[i] !== b[i])
            return false;
    }
    return true;
};
export var allFocusedNodeIds = function (state) {
    var _a, _b;
    var nodeIds = (_a = focus(state)) === null || _a === void 0 ? void 0 : _a.nodeIds;
    // If both the nodeIds reference and the full state are unchanged, return cached result
    if (nodeIds === _prevNodeIds && state === _prevState) {
        return _prevResult;
    }
    _prevNodeIds = nodeIds;
    _prevState = state;
    var newResult = (_b = nodeIds === null || nodeIds === void 0 ? void 0 : nodeIds.filter(function (n) { var _a; return (_a = findNodeInState(state, n)) === null || _a === void 0 ? void 0 : _a.node; })) !== null && _b !== void 0 ? _b : [];
    // Only return a new array reference if the content actually changed
    if (shallowArrayEqual(newResult, _prevResult)) {
        return _prevResult;
    }
    _prevResult = newResult;
    return _prevResult;
};
export var singleFocusedNode = function (state) {
    var nodeIds = allFocusedNodeIds(state);
    if ((nodeIds === null || nodeIds === void 0 ? void 0 : nodeIds.length) === 1)
        return nodeIds[0];
    return null;
};
//# sourceMappingURL=focus.js.map