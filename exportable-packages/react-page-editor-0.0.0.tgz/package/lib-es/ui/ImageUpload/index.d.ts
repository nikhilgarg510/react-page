/// <reference types="react" />
export * from './types';
export declare const ImageUpload: import("react").ForwardRefExoticComponent<import("./types").ImageUploadProps & {
    fallback?: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | undefined;
} & import("react").RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
//# sourceMappingURL=index.d.ts.map