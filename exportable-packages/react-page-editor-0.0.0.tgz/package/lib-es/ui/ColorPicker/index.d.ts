/// <reference types="react" />
export declare const ColorPicker: import("react").ForwardRefExoticComponent<import("./types").ColorPickerProps & {
    fallback?: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | undefined;
} & import("react").RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
export declare const ColorPickerField: import("react").ForwardRefExoticComponent<{
    label?: string | null | undefined;
    name: string;
} & Omit<Partial<import("uniforms").GuaranteedProps<string>>, "label" | "name"> & Omit<{
    value: string;
    label: string;
    onChange: (v: string | void) => void;
}, "onChange" | "label" | "value" | "changed" | "disabled" | "error" | "errorMessage" | "field" | "fieldType" | "fields" | "id" | "name" | "readOnly" | "showInlineError"> & {
    fallback?: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | undefined;
} & import("react").RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
export * from './colorToString';
export * from './types';
//# sourceMappingURL=index.d.ts.map