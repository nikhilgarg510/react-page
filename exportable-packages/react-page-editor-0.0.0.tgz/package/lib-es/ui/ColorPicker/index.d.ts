/// <reference types="react" />
export declare const ColorPicker: import("react").ForwardRefExoticComponent<import("./types").ColorPickerProps & {
    fallback?: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | undefined;
} & import("react").RefAttributes<unknown>> & {
    load: () => Promise<unknown>;
};
export declare const ColorPickerField: import("react").ForwardRefExoticComponent<{
    label?: string | boolean | null | undefined;
    name: string;
    placeholder?: unknown;
} & Omit<Partial<import("uniforms").GuaranteedProps<string>>, "label" | "placeholder" | "name"> & Omit<{
    value: string;
    label: string;
    onChange: (v: string | void) => void;
}, "label" | "id" | "placeholder" | "onChange" | "name" | "disabled" | "value" | "readOnly" | "error" | "changed" | "errorMessage" | "field" | "fieldType" | "fields" | "showInlineError"> & {
    fallback?: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | undefined;
} & import("react").RefAttributes<unknown>> & {
    load: () => Promise<unknown>;
};
export * from './colorToString';
export * from './types';
//# sourceMappingURL=index.d.ts.map