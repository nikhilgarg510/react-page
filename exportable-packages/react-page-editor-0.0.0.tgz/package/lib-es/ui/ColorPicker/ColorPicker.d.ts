import React from 'react';
import type { ColorPickerProps, ColorPickerState } from './types';
declare class ColorPicker extends React.Component<ColorPickerProps> {
    static defaultProps: Partial<ColorPickerProps>;
    anchorEl: HTMLElement | null;
    state: ColorPickerState;
    handleClickShowColorPicker: (e: React.MouseEvent<HTMLElement>) => void;
    onChange: (color: any) => void;
    render(): JSX.Element;
}
export default ColorPicker;
//# sourceMappingURL=ColorPicker.d.ts.map