import type { RgbaColor } from 'react-colorful';
export declare const colorToString: (c?: RgbaColor | null) => string | undefined;
export declare const stringToColor: (c: string) => RgbaColor | null;
/**
 * Convert RGBA color to hex string
 */
export declare const rgbaToHex: (color: RgbaColor) => string;
/**
 * Convert hex string to RGBA color
 */
export declare const hexToRgba: (hex: string) => RgbaColor | null;
//# sourceMappingURL=colorToString.d.ts.map