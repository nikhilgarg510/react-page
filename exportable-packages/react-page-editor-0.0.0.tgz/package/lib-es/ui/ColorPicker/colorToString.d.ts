import type { RgbaColor } from 'react-colorful';
export declare const colorToString: (c?: RgbaColor | null) => string | undefined;
export declare const stringToColor: (c: string) => RgbaColor | null;
//# sourceMappingURL=colorToString.d.ts.map