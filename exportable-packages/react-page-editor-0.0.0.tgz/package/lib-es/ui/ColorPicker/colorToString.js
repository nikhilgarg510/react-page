import parse from 'color-parse';
export var colorToString = function (c) {
    var _a;
    var result = c ? "rgba(".concat(c.r, ", ").concat(c.g, ", ").concat(c.b, ", ").concat((_a = c.a) !== null && _a !== void 0 ? _a : 1, ")") : undefined;
    return result;
};
export var stringToColor = function (c) {
    var _a;
    if (!c) {
        return null;
    }
    var match = parse(c);
    if (!match || match.space !== 'rgb') {
        console.warn('[stringToColor] Invalid color format:', c);
        return null;
    }
    var result = {
        r: match.values[0],
        g: match.values[1],
        b: match.values[2],
        a: (_a = match.alpha) !== null && _a !== void 0 ? _a : 1,
    };
    return result;
};
/**
 * Convert RGBA color to hex string
 */
export var rgbaToHex = function (color) {
    var toHex = function (value) {
        var hex = Math.round(value).toString(16).padStart(2, '0');
        return hex;
    };
    var hex = "#".concat(toHex(color.r)).concat(toHex(color.g)).concat(toHex(color.b));
    // Include alpha if it's not fully opaque
    if (color.a !== undefined && color.a < 1) {
        return "".concat(hex).concat(toHex(color.a * 255));
    }
    return hex;
};
/**
 * Convert hex string to RGBA color
 */
export var hexToRgba = function (hex) {
    // Remove # if present
    var cleanHex = hex.replace('#', '');
    // Validate hex format
    if (!/^[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/.test(cleanHex)) {
        return null;
    }
    var r = parseInt(cleanHex.substring(0, 2), 16);
    var g = parseInt(cleanHex.substring(2, 4), 16);
    var b = parseInt(cleanHex.substring(4, 6), 16);
    // Check if alpha channel is present
    var a = 1;
    if (cleanHex.length === 8) {
        a = parseInt(cleanHex.substring(6, 8), 16) / 255;
    }
    return { r: r, g: g, b: b, a: a };
};
//# sourceMappingURL=colorToString.js.map