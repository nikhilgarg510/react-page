import parse from 'color-parse';
export var colorToString = function (c) {
    var _a;
    var result = c ? "rgba(".concat(c.r, ", ").concat(c.g, ", ").concat(c.b, ", ").concat((_a = c.a) !== null && _a !== void 0 ? _a : 1, ")") : undefined;
    return result;
};
export var stringToColor = function (c) {
    var _a;
    if (!c) {
        return null;
    }
    var match = parse(c);
    if (!match || match.space !== 'rgb') {
        console.warn('[stringToColor] Invalid color format:', c);
        return null;
    }
    var result = {
        r: match.values[0],
        g: match.values[1],
        b: match.values[2],
        a: (_a = match.alpha) !== null && _a !== void 0 ? _a : 1,
    };
    return result;
};
//# sourceMappingURL=colorToString.js.map