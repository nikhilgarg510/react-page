import React from 'react';
import { connectField } from 'uniforms';
import ColorPicker from './ColorPicker';
import { colorToString, stringToColor } from './colorToString';
import { useUiTranslator } from '../../core/components/hooks';
var ColorPickerField = connectField(function (props) {
    var _a;
    var t = useUiTranslator().t;
    // Use default value if value is undefined
    var currentValue = props.value || 'rgba(0, 0, 255, 1)';
    var parsedColor = stringToColor(currentValue);
    // Don't update during dragging, only on complete
    var handleChange = function (v) {
        // Don't call props.onChange here to avoid re-renders while dragging
    };
    var handleChangeComplete = function (v) {
        var colorString = colorToString(v);
        // Only save on complete
        props.onChange(colorString);
    };
    return (React.createElement(ColorPicker, { style: { marginBottom: 8 }, color: parsedColor, buttonContent: (_a = t(props.label)) !== null && _a !== void 0 ? _a : '', onChange: handleChange, onChangeComplete: handleChangeComplete }));
});
/**
 * A component that can be used in autoforms (uniforms)
 */
export default ColorPickerField;
//# sourceMappingURL=ColorPickerField.js.map