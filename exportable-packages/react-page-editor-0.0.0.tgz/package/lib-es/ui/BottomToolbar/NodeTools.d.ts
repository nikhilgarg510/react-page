import React from 'react';
export declare type BottomToolbarMainBarProps = {
    nodeId: string;
    actionsLeft?: React.ReactNode;
};
export declare const BottomToolbarMainBar: React.FC<BottomToolbarMainBarProps>;
//# sourceMappingURL=NodeTools.d.ts.map