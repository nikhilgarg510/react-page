import React from 'react';
import type { PluginDrawerLabels } from '..';
import type { CellPlugin, InsertNewCell } from '../../../core/types';
declare type ItemProps = {
    plugin: CellPlugin;
    insert: InsertNewCell;
    translations: PluginDrawerLabels;
};
declare const Item: React.FC<ItemProps>;
export default Item;
//# sourceMappingURL=index.d.ts.map