import React from 'react';
declare type Props = {
    labelUndo: string;
    labelRedo: string;
};
declare const _default: React.NamedExoticComponent<Props>;
export default _default;
//# sourceMappingURL=index.d.ts.map