import type { ButtonProps } from '@mui/material/Button';
import type { FormControlProps } from '@mui/material/FormControl';
import type { ReactNode } from 'react';
import type { FieldProps } from 'uniforms';
export declare type ListAddFieldProps = FieldProps<unknown, ButtonProps, {
    fullWidth?: FormControlProps['fullWidth'];
    icon?: ReactNode;
    initialCount?: number;
    margin?: FormControlProps['margin'];
    variant?: FormControlProps['variant'];
}>;
declare const _default: import("uniforms").ConnectedField<import("uniforms").GuaranteedProps<unknown> & {
    fullWidth?: boolean | undefined;
    icon?: ReactNode;
    initialCount?: number | undefined;
    margin?: "none" | "normal" | "dense" | undefined;
    variant?: "standard" | "filled" | "outlined" | undefined;
} & Omit<ButtonProps<"button", {}>, "margin" | "variant" | "fullWidth" | "icon" | keyof import("uniforms").GuaranteedProps<unknown> | "initialCount">, unknown>;
export default _default;
//# sourceMappingURL=ListAddField.d.ts.map