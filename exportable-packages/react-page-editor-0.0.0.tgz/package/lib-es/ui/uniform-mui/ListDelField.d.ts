import type { IconButtonProps } from '@mui/material/IconButton';
import type { ReactNode } from 'react';
import type { FieldProps } from 'uniforms';
export declare type ListDelFieldProps = FieldProps<unknown, IconButtonProps, {
    icon?: ReactNode;
}>;
declare const _default: import("uniforms").ConnectedField<import("uniforms").GuaranteedProps<unknown> & {
    icon?: ReactNode;
} & Omit<IconButtonProps<"button", {}>, keyof import("uniforms").GuaranteedProps<unknown> | "icon">, unknown>;
export default _default;
//# sourceMappingURL=ListDelField.d.ts.map