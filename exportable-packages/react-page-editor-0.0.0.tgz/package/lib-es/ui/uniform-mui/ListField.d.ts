import type { ListProps } from '@mui/material/List';
import type { ReactNode } from 'react';
import type { FieldProps } from 'uniforms';
export declare type ListFieldProps = FieldProps<unknown[], ListProps, {
    addIcon?: ReactNode;
    initialCount?: number;
    itemProps?: Record<string, unknown>;
}>;
declare const _default: import("uniforms").ConnectedField<import("uniforms").GuaranteedProps<unknown[]> & {
    addIcon?: ReactNode;
    initialCount?: number | undefined;
    itemProps?: Record<string, unknown> | undefined;
} & Omit<ListProps<"ul", {}>, "initialCount" | keyof import("uniforms").GuaranteedProps<unknown[]> | "addIcon" | "itemProps">, unknown[] | undefined>;
export default _default;
//# sourceMappingURL=ListField.d.ts.map