import type { ReactNode } from 'react';
import type { ListItemProps } from '@mui/material/ListItem';
export declare enum DragItemType {
    ListItemField = "ListItemField"
}
export declare type ListItemFieldProps = {
    children?: ReactNode;
    dense?: ListItemProps['dense'];
    disableGutters?: ListItemProps['disableGutters'];
    divider?: ListItemProps['divider'];
    removeIcon?: ReactNode;
    dragIcon?: ReactNode;
    moveItemUpIcon?: ReactNode;
    moveItemDownIcon?: ReactNode;
    disableSortable?: boolean;
    value?: unknown;
    name?: string;
};
declare const _default: import("uniforms").ConnectedField<ListItemFieldProps, unknown>;
export default _default;
//# sourceMappingURL=ListItemField.d.ts.map