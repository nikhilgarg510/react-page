import type { IconButtonProps } from '@mui/material/IconButton';
import type { ReactNode } from 'react';
import type { FieldProps } from 'uniforms';
export declare type ListSortFieldProps = FieldProps<unknown, IconButtonProps, {
    iconUp?: ReactNode;
    iconDown?: ReactNode;
    dragIcon?: ReactNode;
    handleMove: (fromIndex: number, toIndex: number) => void;
}>;
declare const _default: import("uniforms").ConnectedField<import("uniforms").GuaranteedProps<unknown> & {
    iconUp?: ReactNode;
    iconDown?: ReactNode;
    dragIcon?: ReactNode;
    handleMove: (fromIndex: number, toIndex: number) => void;
} & Omit<IconButtonProps<"button", {}>, keyof import("uniforms").GuaranteedProps<unknown> | "iconUp" | "iconDown" | "dragIcon" | "handleMove">, unknown>;
export default _default;
//# sourceMappingURL=ListSortField.d.ts.map