var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
import React from 'react';
import ListItemMaterial from '@mui/material/ListItem';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import { useDrag, useDrop } from 'react-dnd';
import { connectField, joinName, useField } from 'uniforms';
import AutoField from './AutoField';
import ListDelField from './ListDelField';
import ListSortField from './ListSortField';
export var DragItemType;
(function (DragItemType) {
    DragItemType["ListItemField"] = "ListItemField";
})(DragItemType || (DragItemType = {}));
function ListItem(_a) {
    var _b;
    var _c = _a.children, children = _c === void 0 ? React.createElement(AutoField, { label: null, name: "" }) : _c, _d = _a.dense, dense = _d === void 0 ? true : _d, disableGutters = _a.disableGutters, divider = _a.divider, removeIcon = _a.removeIcon, moveItemUpIcon = _a.moveItemUpIcon, moveItemDownIcon = _a.moveItemDownIcon, _e = _a.dragIcon, dragIcon = _e === void 0 ? React.createElement(DragIndicatorIcon, null) : _e, disableSortable = _a.disableSortable, value = _a.value, name = _a.name;
    var nameParts = joinName(null, name);
    var nameIndex = +nameParts[nameParts.length - 1];
    var parentName = joinName(nameParts.slice(0, -1));
    var parent = useField(parentName, {}, { absoluteName: true })[0];
    var moveItem = function (fromIndex, toIndex) {
        var _a, _b;
        var value = ((_a = parent.value) !== null && _a !== void 0 ? _a : []).slice();
        value.splice(fromIndex, 1);
        value.splice(toIndex, 0, ((_b = parent.value) !== null && _b !== void 0 ? _b : [])[fromIndex]);
        parent.onChange(value);
    };
    var _f = __read(useDrag(function () { return ({
        type: DragItemType.ListItemField,
        item: { name: name, originalIndex: nameIndex },
    }); }, [value, nameIndex, moveItem]), 2), drag = _f[1];
    var _g = __read(useDrop(function () { return ({
        accept: DragItemType.ListItemField,
        drop: function (draggedItem, monitor) {
            var didDrop = monitor.canDrop();
            if (didDrop && draggedItem.name !== name)
                moveItem(draggedItem.originalIndex, nameIndex);
        },
    }); }, [moveItem]), 2), drop = _g[1];
    var disableSort = disableSortable !== null && disableSortable !== void 0 ? disableSortable : ((_b = parent.value) !== null && _b !== void 0 ? _b : []).length < 2;
    return (React.createElement(ListItemMaterial, { dense: dense, disableGutters: disableGutters, divider: divider, ref: function (node) { return (disableSort ? null : drag(drop(node))); }, sx: { gap: '0.5rem' } },
        React.createElement(ListSortField, { name: "", iconUp: moveItemUpIcon, iconDown: moveItemDownIcon, handleMove: moveItem, dragIcon: dragIcon, disabled: disableSort }),
        children,
        React.createElement(ListDelField, { name: "", icon: removeIcon })));
}
export default connectField(ListItem, {
    initialValue: false,
});
//# sourceMappingURL=ListItemField.js.map