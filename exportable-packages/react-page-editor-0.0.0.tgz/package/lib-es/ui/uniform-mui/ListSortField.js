var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import { ButtonGroup, Stack, styled } from '@mui/material';
import IconButtonMaterial from '@mui/material/IconButton';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import React from 'react';
import { connectField, filterDOMProps, joinName, useField } from 'uniforms';
var IconButton = styled(IconButtonMaterial)({ padding: 0 });
function ListSort(_a) {
    var _b, _c;
    var disabled = _a.disabled, _d = _a.iconUp, iconUp = _d === void 0 ? React.createElement(ArrowUpwardIcon, null) : _d, _e = _a.iconDown, iconDown = _e === void 0 ? React.createElement(ArrowDownwardIcon, null) : _e, _f = _a.dragIcon, dragIcon = _f === void 0 ? React.createElement(DragIndicatorIcon, null) : _f, handleMove = _a.handleMove, name = _a.name, readOnly = _a.readOnly, props = __rest(_a, ["disabled", "iconUp", "iconDown", "dragIcon", "handleMove", "name", "readOnly"]);
    var nameParts = joinName(null, name);
    var nameIndex = +nameParts[nameParts.length - 1];
    var parentName = joinName(nameParts.slice(0, -1));
    var parent = useField(parentName, {}, { absoluteName: true })[0];
    var limitNotReachedUp = !disabled && nameIndex !== 0;
    var limitNotReachedDown = !disabled && nameIndex !== ((_b = parent.value) !== null && _b !== void 0 ? _b : []).length - 1;
    return (React.createElement(Stack, { direction: "row" },
        React.createElement(IconButton, { disabled: ((_c = parent.value) !== null && _c !== void 0 ? _c : []).length < 2, size: "large", sx: { padding: 0 } }, dragIcon),
        React.createElement(ButtonGroup, { orientation: "vertical", size: "large" },
            React.createElement(IconButton, __assign({}, filterDOMProps(props), { disabled: !limitNotReachedUp, onClick: function () { return handleMove(nameIndex, nameIndex - 1); } }), iconUp),
            React.createElement(IconButton, __assign({}, filterDOMProps(props), { disabled: !limitNotReachedDown, onClick: function () { return handleMove(nameIndex, nameIndex + 1); } }), iconDown))));
}
export default connectField(ListSort, {
    initialValue: false,
    kind: 'leaf',
});
//# sourceMappingURL=ListSortField.js.map