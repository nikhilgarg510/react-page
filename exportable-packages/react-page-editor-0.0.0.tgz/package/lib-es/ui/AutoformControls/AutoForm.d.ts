import type { ReactNode } from 'react';
import React from 'react';
import type { AutoFormProps } from 'uniforms';
declare type OptionalFields = 'autosaveDelay' | 'error' | 'label' | 'noValidate' | 'onValidate' | 'validate' | 'autosave';
declare const _default: React.ForwardRefExoticComponent<Omit<AutoFormProps<any>, OptionalFields> & Partial<AutoFormProps<any>> & {
    children?: ReactNode;
} & React.RefAttributes<any>>;
export default _default;
//# sourceMappingURL=AutoForm.d.ts.map