import React from 'react';
import type { AutoformControlsDef, CellPluginComponentProps, DataTType } from '../../core/types';
export declare const AutoForm: React.ForwardRefExoticComponent<Pick<Omit<import("uniforms").AutoFormProps<any>, "label" | "error" | "noValidate" | "validate" | "autosave" | "autosaveDelay" | "onValidate"> & Partial<import("uniforms").AutoFormProps<any>> & {
    children?: React.ReactNode;
} & React.RefAttributes<any> & {
    fallback?: React.ReactElement<any, string | React.JSXElementConstructor<any>> | undefined;
}, "key" | "fallback" | "validate" | "onValidate" | keyof import("uniforms").BaseFormProps<any> | "errorsField" | "submitField" | "validator" | "onChangeModel"> & React.RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
export declare const AutoField: React.ForwardRefExoticComponent<Pick<import("uniforms").UnknownObject & {
    component?: import("uniforms").Component | undefined;
    experimental_absoluteName?: boolean | undefined;
    name: string;
} & {
    fallback?: React.ReactElement<any, string | React.JSXElementConstructor<any>> | undefined;
}, string> & React.RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
export declare const AutoFields: React.ForwardRefExoticComponent<import("../uniform-mui").AutoFieldsProps & {
    fallback?: React.ReactElement<any, string | React.JSXElementConstructor<any>> | undefined;
} & React.RefAttributes<any>> & {
    load: () => Promise<unknown>;
};
declare type Props<T extends DataTType> = CellPluginComponentProps<T> & AutoformControlsDef<T>;
export declare function AutoformControls<T extends DataTType>(props: Props<T>): JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map