import { deepEquals } from '@react-page/editor';
import React, { useCallback, useEffect, useMemo } from 'react';
import { createEditor, Transforms } from 'slate';
import { ReactEditor, Slate, withReact } from 'slate-react';
import withInline from '../slateEnhancer/withInline';
import withPaste from '../slateEnhancer/withPaste';
import DialogVisibleProvider from './DialogVisibleProvider';
var SlateProvider = function (props) {
    var data = props.data, plugins = props.plugins, children = props.children, defaultPluginType = props.defaultPluginType;
    var editor = useMemo(function () {
        return withPaste(plugins, defaultPluginType)(withReact(withInline(plugins)(createEditor())));
    }, []);
    // unfortunatly, slate broke the controlled input pattern. So we have to hack our way around it, see https://github.com/ianstormtaylor/slate/issues/4992
    useMemo(function () {
        // better do this in use effect to avoid certain timing edge cases
        editor.children = (data === null || data === void 0 ? void 0 : data.slate) || [
            {
                type: 'paragraph',
                children: [{ text: '' }],
            },
        ];
    }, [data === null || data === void 0 ? void 0 : data.slate]);
    useEffect(function () {
        try {
            // focus - only if editor has been properly mounted
            if (ReactEditor.isFocused(editor)) {
                return; // already focused
            }
            // Check if editor is mounted by verifying it can find a DOM node
            var domNode = ReactEditor.toDOMNode(editor, editor);
            if (domNode) {
                ReactEditor.focus(editor);
            }
        }
        catch (e) {
            // ignore, can happen when editor is not fully mounted yet
            console.debug('Could not focus editor:', e);
        }
        if (data.selection) {
            // update seleciton, if changed from outside (e.g. through undo)
            try {
                Transforms.select(editor, data.selection);
            }
            catch (e) {
                // ignore
            }
        }
        else {
            // deselect, otherwise slate might throw an eerror if cursor is now on a non existing dom node
            try {
                Transforms.deselect(editor);
            }
            catch (e) {
                // ignore
            }
        }
    }, [data === null || data === void 0 ? void 0 : data.slate, data === null || data === void 0 ? void 0 : data.selection]);
    var onChange = useCallback(function () {
        var dataEqual = deepEquals(editor.children, data === null || data === void 0 ? void 0 : data.slate);
        var selectionEqual = deepEquals(editor.selection, data === null || data === void 0 ? void 0 : data.selection);
        if (!dataEqual || !selectionEqual)
            props.onChange({
                slate: editor.children,
                selection: editor.selection,
            }, {
                // mark as not undoable when state is same
                // that happens if only selection was changed
                notUndoable: dataEqual,
            });
    }, [data === null || data === void 0 ? void 0 : data.slate, props.onChange]);
    var initialValue = (data === null || data === void 0 ? void 0 : data.slate) || [
        {
            type: 'paragraph',
            children: [{ text: '' }],
        },
    ];
    return (React.createElement(DialogVisibleProvider, null,
        React.createElement(Slate, { editor: editor, initialValue: initialValue /*
        this is confusingly only for the initial value since slate 0.70something, see https://github.com/ianstormtaylor/slate/issues/4992
      */, onChange: onChange }, children)));
};
export default SlateProvider;
//# sourceMappingURL=SlateProvider.js.map