import React from 'react';
import type { SlateProps } from '../types/component';
declare const _default: React.MemoExoticComponent<(props: Pick<SlateProps, "translations" | "plugins">) => JSX.Element>;
export default _default;
//# sourceMappingURL=Controls.d.ts.map