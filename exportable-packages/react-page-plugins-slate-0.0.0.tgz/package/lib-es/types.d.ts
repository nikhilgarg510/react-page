import type { DataTType } from '@react-page/editor';
export declare type Data = DataTType;
export declare type CustomText = {
    text: string;
    data?: Data;
    type?: string;
};
//# sourceMappingURL=types.d.ts.map