import type { Node, Range } from 'slate';
export declare type SlateState = {
    slate: Node[];
    selection?: Range | null;
};
//# sourceMappingURL=state.d.ts.map